<?php
function task1($pswd, $strr)
{
	
	$a = $pswd;
	
	// intialize variables
	$code = "";
	$ki = 0;
	//$kl = strlen($pswd);
	//$length = strlen($text);
	
	// iterate over each character
	
	if(preg_match("/^[0-9,]+$/", $a)){
    $a = str_replace(',', '', $a);
}
//echo $a;

$array1  = array_map('intval', str_split($a));
$string2 = implode('+', $array1);
//echo '['.'"'.$string2.'"'.','.']';


$input = $pswd;
//$input2 = explode(',',$input);
$input3 = str_split($input);
$result = array_sum($input3);
//echo $result;

$res = '['.'"'.$string2.'"'.','."" . $result.']';
	
	// return the result with occurencies of each character in alphabetical order
	return $res;
}

?>