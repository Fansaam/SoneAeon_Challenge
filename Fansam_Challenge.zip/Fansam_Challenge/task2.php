<?php

// initialize variables
$pswd = "";
$code = "";
$error = "";
$valid = true;
$color = "orange";


// if form was submitted
if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    // declare needed function funtions
    require_once('task2_function.php');
    
    // set the variables
    $pswd = $_POST['pswd'];
    $code = $_POST['code'];
    
    // check if a text is provided
    if (empty($_POST['pswd']))
    {
        $error = "Please enter a string here!";
        $valid = false;
    }
    
    
    else if (isset($_POST['pswd']))
    {
        if (!ctype_alpha($_POST['pswd']))
        {
            $error = "Your string should contain only alphabetical characters!";
            $valid = false;
        }
    }
    
    // inputs valid
    if ($valid)
    {
        //
        if (isset($_POST['task2']))
        {
            $code = task2($pswd);
            $error = "Occurencies Has been successfully Generated Below!";
            $color = "orange";
            $fontsize = "30px";
        }
            
        
    }
}

?>
<!doctype html>
<html lang="en">
    <head>

        <!-- meta data & title -->
        <meta charset="utf-8">
        <title>Welcome To Samuel Fanijo Web Application</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
        <link href="http://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" type="text/css" media="all" href="assets/css/style-projects.css">
        



  <!-- CSS
         ================================================== -->
        <!-- Bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css"/>
        <!-- FontAwesome -->
        <link rel="stylesheet" href="css/font-awesome.min.css"/>
        <!-- Animation -->
        <link rel="stylesheet" href="css/animate.css" />
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="css/owl.carousel.css"/>
         <link rel="stylesheet" href="css/owl.theme.css"/>
         <!-- Pretty Photo -->
         <link rel="stylesheet" href="css/prettyPhoto.css"/>
         <link rel="stylesheet" href="css/flexslider.css"/>
         <link rel="stylesheet" href="css/red.css"/>

        <!-- Template styles-->
        <link rel="stylesheet" href="css/custom.css" />
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />





        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/cpelogo.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
    </head>
  <body>

    <!-- Header -->

    <header id="header" class="navbar-fixed-top navbar-inverse video-menu" role="banner" style="background-color:green;height:80px">
        <div class="container">
            <!-- <div class="row"> -->
                 <div class="navbar-header ">
                     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                     <a class="navbar-brand wow fadeInDownBig" href="index.html"><img src="pic.jpg" style="height:80px;width:70px;margin-top:-20px" !important></a><p style="color:white;font-size:28px;font-family:times;"><a style="font-size:35px;color:white"> S</a>amuel <a style="font-size:35px;color:white"><br> F</a>anijo <br><a style="color:white;font-size:17px;margin-left:115px"><em style="margin-left:-15px">samuel.fanijo.0885@fuoye.edu.ng</em></a>   
                 </div><!--Navbar header End-->
                    <nav class="collapse navbar-collapse navigation" id="bs-example-navbar-collapse-1" width="200" role="navigation" style="">
                        <ul class="nav navbar-nav navbar-right ">
                            <li> <a href="index.php" class="page-scroll">Home </a></li>
                            <li><a href="task1.php" class="page-scroll" >Task One</a> </li>
                            <li class="active"><a href="task2.php"  class="page-scroll">Task Two</a> </li>
                            
                            
                        </ul>
                     </nav>
                </div><!-- /.container-fluid -->
</header>
    <!--End Header -->



    <section id="services" class="services-section section-global-wrapper">
        <div class="container">
            <div class="row">
                
            </div>
      
            <!-- Begin Services Row 1 -->
           
            <!-- End Serivces Row 1 -->
      
            <!-- Begin Services Row 2 -->
            <div class="row services-row services-row-tail services-row-2">
                
        
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="services-group wow animated zoomIn" data-wow-offset="40" style="background-color:green">
                        
                       <h4 class="services-header-title" style="color:white;font-size:37px;font-format:arial">Task Two Solution Interface</h3><p class="services-body" style="color:white;">

                        <div class="col-lg-5-center">
                    <div class="feedback-form" style="text-align:center">
          
                        <div id="contact-response"></div>
                              
                        <form action="task2.php"  method="post" style="text-align:centre">
                            <fieldset>
                                <div class="form-group form-group-fullname">
                                    <label class="control-label" for="fullname">Enter Your Input String Here *
                                    <input type="text" class="form-control" style="width:500px;font-size: 18px" name="pswd" id="pass" value="<?php echo htmlspecialchars($pswd); ?>" placeholder="Enter any input String without Space" required></label>
                                </div>

                                
                                 <button type="submit" name="task2" class="btn btn-primary-white" value="Encode" onclick="validate(1)" style="background-color:white;color:green;">Calculate Occurencies</button><br><br>
                              


                                <tr>
                    <td><center><div style="color: <?php echo htmlspecialchars($color) ?>"><?php echo htmlspecialchars($error) ?></div></center></td>
                </tr>
                                <div class="form-group form-group-message">
                                    <label class="control-label" for="message">The Result : Number of Occurencies for each Letter in Alphabetical Order will Be Displayed Here </label>
                                    <textarea class="form-control"  rows="6" required id="box" name="code" readonly="" style="font-size: 18px"><?php echo htmlspecialchars($code); ?>

                                    </textarea>
                                </div>         
                                  
                               

                                
                            </fieldset>
                        </form>
                    </div> 
                </div>
            </div></p>
                        
                    </div>
                </div>
        
                
            </div>
            <!-- End Serivces Row 2 -->
    
        </div>      
    </section>
    <!-- End #services-section -->



    
    
    <!--End Main Container -->

    <!-- Footer -->
      <!-- Footer -->
     
    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
      new WOW().init();
    </script>
     <script type="text/javascript">$(function() {
  $('a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});</script>

  </body>
</html>
