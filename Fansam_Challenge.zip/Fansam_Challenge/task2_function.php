<?php

// function to detect the characters in the text given and produce respective occurencies
function task2($pswd, $strr)
{
	// change key to lowercase for simplicity
	$pswd = strtolower($pswd);
	
	// intialize variables
	$code = "";
	$ki = 0;
	//$kl = strlen($pswd);
	//$length = strlen($text);
	
	// iterate over each character text
	
	foreach (count_chars($pswd, 1) as $strr => $value) {

if ($value > 1) {
	 $res .= "The Alphabet ". '-'. chr($strr) .'-'. " Occurred $value times in the Input String\n\n";

}
else{
   $res .= "The Alphabet ". '-'. chr($strr) .'-'. " Occurred $value time in the Input String\n\n";
}
}
	
	// return the result with occurencies of each character in alphabetical order
	return $res;
}










?>