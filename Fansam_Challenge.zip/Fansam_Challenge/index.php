
<!doctype html>
<html lang="en">
    <head>

        <!-- meta data & title -->
        <meta charset="utf-8">
        <title>Welcome To Samuel Fanijo's Web App</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300">
        <link href='http://fonts.googleapis.com/css?family=PT+Sans' rel='stylesheet' type='text/css'>
        <link href="http://fonts.googleapis.com/css?family=Raleway" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/animate.min.css">
        <link rel="stylesheet" type="text/css" media="all" href="assets/css/style-projects.css">
        



  <!-- CSS
         ================================================== -->
        <!-- Bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css"/>
        <!-- FontAwesome -->
        <link rel="stylesheet" href="css/font-awesome.min.css"/>
        <!-- Animation -->
        <link rel="stylesheet" href="css/animate.css" />
        <!-- Owl Carousel -->
        <link rel="stylesheet" href="css/owl.carousel.css"/>
         <link rel="stylesheet" href="css/owl.theme.css"/>
         <!-- Pretty Photo -->
         <link rel="stylesheet" href="css/prettyPhoto.css"/>
         <link rel="stylesheet" href="css/flexslider.css"/>
         <link rel="stylesheet" href="css/red.css"/>

        <!-- Template styles-->
        <link rel="stylesheet" href="css/custom.css" />
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />





        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/cpelogo.jpg">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">
    </head>
  <body>

    <!-- Header -->

    <header id="header" class="navbar-fixed-top navbar-inverse video-menu" role="banner" style="background-color:green;height:80px">
        <div class="container">
            <!-- <div class="row"> -->
                 <div class="navbar-header ">
                     <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                    <a class="navbar-brand wow fadeInDownBig" href="index.html"><img src="pic.jpg" style="height:80px;width:70px;margin-top:-20px" !important></a><p style="color:white;font-size:28px;font-family:times;"><a style="font-size:35px;color:white"> S</a>amuel <a style="font-size:35px;color:white"><br> F</a>anijo <br><a style="color:white;font-size:17px;margin-left:115px"><em style="margin-left:-15px">samuel.fanijo.0885@fuoye.edu.ng</em></a>  
                 </div><!--Navbar header End-->
                    <nav class="collapse navbar-collapse navigation" id="bs-example-navbar-collapse-1" width="200" role="navigation" style="">
                        <ul class="nav navbar-nav navbar-right ">
                            <li class="active"> <a href="index.php" class="page-scroll">Home</a></li>
                            <li><a href="task1.php" class="page-scroll" >Task || One</a> </li>
                            <li><a href="task2.php"  class="page-scroll">Task || Two</a> </li>
                            
                            
                        </ul>
                     </nav>
                </div><!-- /.container-fluid -->
</header>
    <!--End Header -->

<section id="home" class="hero landing hero-section">
        

        <div class="parallax-overlay"><img src="background.png" height="1000" width="1500" /></div>

        <div class="container">

            <div class="hero-content text-center">
                <div class="hero-text wow fadeIn" data-wow-delay=".8s">
                    <h3 class="hero-title" style="color:green"><span>Samuel Fanijo -</span> Interview Technical Challenge Demo</h3>
                    <p class="hero-description" style="font-size:25px;color:green">Sone Aeon Technologies, Lagos.</p>
                    <p class="hero-buttons">
                        <a href="task1.php" class="btn btn-main featured" style="color:green">
                            <strong style="color:white">Task One </strong> </i>
                        </a>
                         <a href="task2.php" class="btn btn-dark">
                            <strong style="color:white">Task Two</strong> </i>
                        </a>

                    </p>
                </div><!--/ Hero text end -->
            </div><!--/ Hero content end -->
        </div><!--/ Container end -->
    </section><!--/ Home end -->

   
    <!-- End #services-section -->



    
    
    <!--End Main Container -->

    <!-- Footer -->
      <!-- Footer -->
      <footer> 
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <h3 style="font-size:30px"><i class="fa fa-map-marker"></i> Contact:</h3>
                    <p class="footer-contact">
                        Department Of Computer Engineering<br>
                        Federal University Oye-Ekiti<br>
                        
                        Email: samuel.fanijo.0885@fuoye.edu.ng<br>
                    </p>
                </div>
                   <div class="col-md-4">
                    
                </div>
                 <div class="col-md-4">
                    <h3 style="font-size:30px"><i class=""></i> Developed By:</h3>
                    <p class="footer-contact">
                        Samuel Fanijo<br>
                        Department Of Computer Engineering<br>
                        
                        
                        Email: samuel.fanijo.0885@fuoye.edu.ng<br>
                    </p>
                </div>
                
        </div>
      </div>
    </footer>
    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
      new WOW().init();
    </script>
     <script type="text/javascript">$(function() {
  $('a[href*=#]:not([href=#])').click(function() {
    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
      var target = $(this.hash);
      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
      if (target.length) {
        $('html,body').animate({
          scrollTop: target.offset().top
        }, 1000);
        return false;
      }
    }
  });
});</script>

  </body>
</html>
